package es.umu.soccerreport;

public enum TipoEquipo {
	Local,Visitante,arbitro,AA1,AA2,INCSPINNER;
}
